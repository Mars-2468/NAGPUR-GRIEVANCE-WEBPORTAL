<?php

return array(

	'Select' => 'Välj', // Select
	'Erase' => 'Radera', // Erase
	'Open' => 'Öppna', // Open
	'Confirm_del' => 'Är du säker på att du vill radera denna fil?', //Are you sure you want to delete this file?
	'All' => 'Alla', // All
	'Files' => 'Filer', // Files
	'Images' => 'Bilder', // Images
	'Archives' => 'Arkiv', // Archives
	'Error_Upload' => 'Den uppladdade filen överskrider max storleken.', // The uploaded file exceeds the max size allowed.
	'Error_extension' => 'Filtypen är ej tillåten.', // File extension is not allowed.
	'Upload_file' => 'Ladda upp', // Upload
	'Filters' => 'Filter', // Filters
	'Videos' => 'Videor', // Videos
	'Music' => 'Musik', // Music
	'New_Folder' => 'Ny katalog', // New Folder
	'Folder_Created' => 'Katalogen har skapats', // Folder correctly created
	'Existing_Folder' => 'Befintlig katalog', // Existing folder
	'Confirm_Folder_del' => 'Är du säker på att du vill radera denna katalog samt dess innehåll?', // Are you sure to delete the folder and all the elements in it?
	'Return_Files_List' => 'Tillbaka till filvisaren', // Return to files list
	'Preview' => 'Förhandsgranska', // Preview
	'Download' => 'Ladda hem', // Download
	'Insert_Folder_Name' => 'Ange katalog namn:', // Insert folder name:
	'Root' => 'root', // root
	'Rename' => 'Byt namn', // Rename
	'Back' => 'tillbaka', // back
	'View' => 'Visa', // View
	'View_list' => 'Listvy', // List view
	'View_columns_list' => 'Columnvy', // Columns list view
	'View_boxes' => 'Boxvy', // Box view
	'Toolbar' => 'Verktygsfält', // Toolbar
	'Actions' => 'Åtgärder', // Actions
	'Rename_existing_file' => 'Det finns redan en fil med det namnet', // The file is already existing
	'Rename_existing_folder' => 'Det finns redan en katalog med det namnet', // The folder is already existing
	'Empty_name' => 'Du har ej angivet något namn', // The name is empty
	'Text_filter' => 'text filter', // text filter
	'Swipe_help' => 'Svep över filnamnet/katalognamnet för att visa åtgärder', // Swipe the name of file/folder to show options
	'Upload_base' => 'Basal uppladdning', // Base upload
	'Upload_java' => 'JAVA uppladdning (för stora filer)', // JAVA upload (big size files)
	'Upload_java_help' => "Om Java Appleten inte laddar, 1. säkerställ att Java är installerat, <a href='http://java.com/en/download/'>ladda hem</a> och installera om det saknas  2. säkerställ att programmet inte blokeras av din brandvägg", // If the Java Applet doesn't load, 1. make sure you have Java installed, otherwise <a href='http://java.com/en/download/'>[download link]</a>   2. make sure nothing is blocked by your firewall
	'Upload_base_help' => "Dra och släpa filer eller klicka ovan och välj en eller flera filer. När uppladningen är klar, klicka på 'Tillbaka till filvisaren' knappen.", // Drag & Drop files or click in the area above (modern browsers) and select the file(s). When the upload is complete, click the 'Return to files list' button.
	'Type_dir' => 'katalog', // dir
	'Type' => 'Typ', // Type
	'Dimension' => 'Dimension', // Dimension
	'Size' => 'Storlek', // Size
	'Date' => 'Datum', // Date
	'Filename' => 'Filname', // Filename
	'Operations' => 'Handlingar', // Operations
	'Date_type' => 'y-m-d', // y-m-d
	'OK' => 'OK', // OK
	'Cancel' => 'Avbryt', // Cancel
	'Sorting' => 'sortering', // sorting
	'Show_url' => 'visa sökväg', // show URL
	'Extract' => 'packa upp här', // extract here
	'File_info' => 'fil information', // file info
	'Edit_image' => 'editera bild', // edit image
	'Duplicate' => 'Duplicera', // Duplicate
	'Folders' => 'Folders', // Folders
	'Copy' => 'Kopiera', // Copy
	'Cut' => 'Klipp ut', // Cut
	'Paste' => 'Klistra in', // Paste
	'CB' => 'Urklipp', //CB,  clipboard
	'Paste_Here' => 'Klistra in i denna mapp', // Paste to this directory
	'Paste_Confirm' => 'Är du säker på att du vill klistra in i denna mapp? Befintliga filer och mappar kan bli överskrivna.', // Are you sure you want to paste to this directory? This will overwrite existing files/folders if encountered any.
	'Paste_Failed' => 'Misslyckades med att klistra in fil(er)', // Failed to paste file(s)
	'Clear_Clipboard' => 'Rensa urklipp', // Clear clipboard
	'Clear_Clipboard_Confirm' => 'Är du säker på att du vill rensa urklipp?', // Are you sure you want to clear the clipboard?
	'Files_ON_Clipboard' => 'Det finns filer i urklipp.', // There are files on the clipboard.
	'Copy_Cut_Size_Limit' => 'De valda filerna/mapparna är för stora för att %s. Gräns: %d MB per operation', // The selected files/folders are too big to %s. Limit: %d MB/operation      %s = cut or copy
	'Copy_Cut_Count_Limit' => 'För många filer/mappar är valda för att de ska kunna %s. Gräns: #d filer per operation', // You selected too many files/folders to %s. Limit: %d files/operation     %s = cut or copy
	'Copy_Cut_Not_Allowed' => 'Du har ej behörighet att %s filer.', // You are not allowed to %s files.        %s(1) = cut or copy, %s(2) = files or folders
	'Aviary_No_Save' => 'Misslyckades med att spara bild', // Could not save image
	'Zip_No_Extract' => 'Misslyckades med att packa upp. Filen kan eventuellt vara korrupt.', // Could not extract. File might be corrupt.
	'Zip_Invalid' => 'Filtypen stöds ej. Stödja filtyper: zip, gz och tar.', // This extension is not supported. Valid: zip, gz, tar.
	'Dir_No_Write' => 'Det går ej att skriva till den valda sökvägen.', // The directory you selected is not writable.
	'Function_Disabled' => 'Funktionen för att %s är inaktiverad.', // The %s function has been disabled by the server.       %s = cut or copy
	'File_Permission' => 'File permission',
	'File_Permission_Not_Allowed' => 'Changing %s permissions are not allowed.', // %s = files or folders
	'File_Permission_Recursive' => 'Apply recursively?',
	'File_Permission_Wrong_Mode' => "The supplied permission mode is incorrect.",
	'User' => 'User',
	'Group' => 'Group',
	'Yes' => 'Yes',
	'No' => 'No',
	'Lang_Not_Found' => 'Could not find language.',
	'Lang_Change' => 'Change the language',
	'File_Not_Found' => 'Could not find the file.',
	'File_Open_Edit_Not_Allowed' => 'You are not allowed to %s this file.', // %s = open or edit
	'Edit' => 'Edit',
	'Edit_File' => "Edit file's content",
	'File_Save_OK' => "File successfully saved.",
	'File_Save_Error' => "There was an error while saving the file.",
	'New_File' => 'New File',
	'No_Extension' => 'You have to add a file extension.',
	'Valid_Extensions' => 'Valid extensions: %s', // %s = txt,log etc.
	'Upload_message' => "Drop file here to upload",

	'SERVER ERROR' => "SERVER ERROR",
	'forbiden' => "Forbiden",
	'wrong path' => "Wrong path",
	'wrong name' => "Wrong name",
	'wrong extension' => "Wrong extension",
	'wrong option' => "Wrong option",
	'wrong data' => "Wrong data",
	'wrong action' => "Wrong action",
	'wrong sub-action' => "Wrong sub-actio",
	'no action passed' => "No action passed",
	'no path' => "No path",
	'no file' => "No file",
	'view type number missing' => "View type number missing",
	'Not enought Memory' => "Not enought Memory",
	'max_size_reached' => "Your image folder has reach its maximale size of %d MB.", //%d = max overall size
	'B' => "B",
	'KB' => "KB",
	'MB' => "MB",
	'GB' => "GB",
	'TB' => "TB",
	'total size' => "Total size",
);
